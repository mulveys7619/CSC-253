﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace AreaClass
{
    class Program
    {
        double pi = Math.PI;
        static void Main(string[] args)
        {
            double pi = Math.PI;
            Console.WriteLine(ClassLibrary.AreaClass.Area(pi, 6.0));
            Console.WriteLine(ClassLibrary.AreaClass.Area(4, 10));
            Console.WriteLine(ClassLibrary.AreaClass.Area(pi, 6, 5));
            Console.ReadLine();
            
        }
        
    }
}
