﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class AreaClass
    {
        public static double Area(double pi, double radius)
        {
            double area = pi * (radius * radius);
            return area;
        }
        public static double Area(int width, int length)
        {
            double area = width * length;
            return area;
        }
        public static double Area(double pi, double radius, double height)
        {
            double area = (2 * pi * radius * radius) + height * (2 * pi * radius);
            return area;
        }
    }
}
