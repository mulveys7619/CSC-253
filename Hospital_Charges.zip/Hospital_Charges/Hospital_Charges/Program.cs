﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_Charges
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare Variables
            double days;
            double medCharges;
            double surgCharges;
            double labFees;
            double rehabCharges;
            // GET days spent in hospital stayCharges
            Console.WriteLine("How many days did the patient spend in care?: ");
            while (!double.TryParse(Console.ReadLine(), out days))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID VALUE!");
                Console.WriteLine("How many days did the patient spend in care?: ");
                
            }
            // GET medication charges medCharges
            Console.WriteLine("What are the medication charges?: ");
            while (!double.TryParse(Console.ReadLine(), out medCharges))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID VALUE!");
                Console.WriteLine("What are the medication charges?: ");

            }
            // GET surgical charges surgCharges
            Console.WriteLine("What are the surgical charges?: ");
            while (!double.TryParse(Console.ReadLine(), out surgCharges))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID VALUE!");
                Console.WriteLine("What are the surgical charges?: ");

            }
            // GET lab fees labFees
            Console.WriteLine("What are the lab fees?: ");
            while (!double.TryParse(Console.ReadLine(), out labFees))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID VALUE!");
                Console.WriteLine("What are the lab fees?: ");

            }
            // GET rehabilitation charges rehabCharges
            Console.WriteLine("What are the rehabilitation charges?: ");
            while (!double.TryParse(Console.ReadLine(), out rehabCharges))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID VALUE!");
                Console.WriteLine("What are the rehabilitation charges?: ");

            }

            CalcTotalCharges(CalcStayCharges(days), CalcMiscCharges(medCharges, surgCharges, labFees, rehabCharges));







            Console.ReadLine();



        }
        // CREATE CalcStayCharges method to return total of stayCharges ($350 per day)
        public static double CalcStayCharges(double day)
        {
            double stayCharges = day * 350;
            return stayCharges;
        }
        // CREATE CalcMiscCharges method to return total of medCharges, surgCharges, labFees, and rehabCharges
        public static double CalcMiscCharges(double med, double surg, double lab, double rehab)
        {
            double miscCharges = med + surg + lab + rehab;
            return miscCharges;
        }
        // CREATE CalcTotalCharges method to return overall total
        public static void CalcTotalCharges(double room, double misc)
        {
            
            
            decimal total = Convert.ToDecimal(room) + Convert.ToDecimal(misc);
            Console.WriteLine("Miscellaneous: " + Convert.ToDecimal(misc).ToString("C0"));
            Console.WriteLine("         Room: " + Convert.ToDecimal(room).ToString("C0"));
            Console.WriteLine("        Total: " + total.ToString("C0"));



        }
    }
}
