﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MostFrequentCharacter
{
    public class Program
    {
        /*
         * Most Frequent Character Counter
         * Sean Mulvey
         * CSC 253
         * 09/18/2020
         */
        public static void Main(string[] args)
        {
            int countMax = 0;
            char mostUsed = 'z';
            List<char> charList = new List<char>();
            String userString;
            Console.WriteLine("Enter a string and the program will display the most frequent character: ");
            userString = Console.ReadLine();
            for (int i = 0; i < userString.Length;i++)
            {

                
                charList.Add(userString[i]);
            }
            foreach (char character in charList)
            {
                int count = 0;
                for (int i = 0; i < userString.Length; i++)
                {
                    if (character == charList[i])
                    {
                        count++;
                    }
                    if (count >= countMax)
                    {
                        countMax = count;
                        mostUsed = character;
                    }

                }
                
                
                
            }
            Console.WriteLine("The Most Frequent Character Is " + mostUsed);
            Console.ReadLine();
        }
    }
}
