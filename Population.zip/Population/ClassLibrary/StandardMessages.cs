﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        // Ask user for initialPopulation
        public static String GetInitial()
        {
            return "Enter Current Bacteria Population :";
        }
        // Ask user for growthRate
        public static String GetGrowth()
        {
            return "Enter Bacteria Growth Rate: ";
        }
        // Create Formatted Table of growth over 10 days
        public static string TableHeader()
        {       
            return "             BACTERIA GROWTH\n" +
                   "Day             Number of Bacteria Present\n" +
                   "------------------------------------------\n";
                    
        }
        public static string Result(int time, double population)
        {
            return time + "             " + population + "\n" +
                  "----------------------------------------";
        }
    }
}
