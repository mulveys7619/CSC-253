﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Calculations
    {
        // Create growth formula
        public static double CalculateGrowth(double initialPopulation,double growthRate, int time)
        {
            double finalPopulation = initialPopulation * (growthRate * time);

            return finalPopulation;
        }

            

    }
}
