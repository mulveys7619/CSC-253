﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace Population
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declare variables
            string stringInitialPopulation;
            double initialPopulation;
            string stringGrowthRate;
            double growthRate;
            double check = 0.0;
            int time;
            // Ask user for initialPopulation - StandardMessages
            Console.Write(StandardMessages.GetInitial());
            // Input intialPopulation
            stringInitialPopulation = Console.ReadLine();
            while (!double.TryParse(stringInitialPopulation, out check))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID INPUT!");
                Console.WriteLine(StandardMessages.GetInitial());
                stringInitialPopulation = Console.ReadLine();
            }
            initialPopulation = Convert.ToDouble(stringInitialPopulation);
            

            // Ask user for growthRate - StandardMessages
            Console.WriteLine(StandardMessages.GetGrowth());
            // Input growthRate
            stringGrowthRate = Console.ReadLine();
            while (!double.TryParse(stringGrowthRate, out check))
            {
                Console.WriteLine("ERROR: PLEASE ENTER A VALID INPUT!");
                Console.WriteLine(StandardMessages.GetInitial());
                stringGrowthRate = Console.ReadLine();
            }
            growthRate = Convert.ToDouble(stringGrowthRate);

            // Display Table of changing population - StandardMessages
            Console.WriteLine(StandardMessages.TableHeader());
            // Create for loop to display each day
            for (time = 1; time < 11; time++)
            {
                // Calculate currPopulation - Calculations
                // Dsiplay Result for the day - StandardMessages
                Console.WriteLine(StandardMessages.Result(time, Calculations.CalculateGrowth(initialPopulation, growthRate, time)));
            }


            Console.ReadLine();
            }
        
        
       
        
    }
}
