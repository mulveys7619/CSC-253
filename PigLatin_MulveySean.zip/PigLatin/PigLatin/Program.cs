﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PigLatin
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string userString;
            Console.WriteLine("Enter a sentence to translate it to pig latin: ");
            userString = Console.ReadLine();
            Console.WriteLine(MakePigLatin(userString));
            Console.ReadLine();
        }

        public static string MakePigLatin(string userString)
        {
            string[] words = userString.Split(' ');
            userString = String.Empty;
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length <= 1) continue;
                string output = new String(words[i].ToCharArray());
                output = output.Substring(1, output.Length - 1) + output.Substring(0, 1) + "ay ";
                userString += output;
            }
            return userString.Trim();
        }
    }
}
