﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Random random = new Random();
                StreamWriter outputFile;
                int userNum = 0;
                
                outputFile = File.CreateText("Random Numbers.txt");
                Console.WriteLine("How many random numbers do you want to add?: ");
                userNum = IntValidation(userNum);

                for (int i = 0; i < userNum; i++)
                {
                    int randomNumber = random.Next(1, 100);
                    outputFile.WriteLine(randomNumber);
                    Console.WriteLine("Should write: " + randomNumber + " to file.");
                }
                outputFile.Close();
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public static int IntValidation(int num)
        {
            while (!int.TryParse(Console.ReadLine(), out num))
            {
                Console.WriteLine("Error: Please enter a valid value!");
            }

            return num;
        }

    }
}
