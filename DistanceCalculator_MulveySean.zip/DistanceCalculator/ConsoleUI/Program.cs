﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Program
    {
        
        public static void Main(string[] args)
        {
            double speed = 0;
            double time = 0;
            Console.WriteLine("Enter speed (mph) and time (hour) to calculate distance traveled: ");
            speed = InputValidation(speed);
            time = InputValidation(time);
            Console.WriteLine("The distance travled is " + CalculateDistance(speed, time) + " miles.");
            Console.ReadLine();
        }
        public static double CalculateDistance(double speed, double time)
        {
            double distance = speed * time;
            return distance;
        }
        public static double InputValidation(double input)
        {
            while (!double.TryParse(Console.ReadLine(), out input))
            {
                Console.WriteLine("ERROR: Please enter a valid value!");
            }

            return input;

        }
    }
}
