﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCounter
{
    /*
     *  Sean Mulvey
     * CSC-253
     * Word Average
     * 09/10/2020
     */
    public class Program
    {
        public static void Main(string[] args)
        {
            string userString;
            
            // Display prompt to get string
            Console.WriteLine("Enter a string to count the average number of letters per word: ");
            // get string
            userString = Console.ReadLine();
            // display word count
            
            Console.WriteLine("The average length of each word in the string is " + wordAvg(WordCount(userString)) + " letters.");
            Console.ReadLine();

            

            
        }
        public static List<string> WordCount(string userString)
        {
            int count = 0;
            // create an empty list
            List<string> wordCounter = new List<string>();
            // split each word into a substring and add it to wordCounter list
            wordCounter = userString.Split(' ').ToList();
            // increment count for each word in wordCounter list
            foreach (string value in wordCounter)
            {
                count++;
            }
            return wordCounter;
        }
        public static double wordAvg(List<string> wordCounter)
        {

            double count = 0;
            for (int i = 0; i < wordCounter.Count; i++)
            {
                foreach (char value in wordCounter[i])
                {
                    count++;
                }
            }
            count = count / wordCounter.Count;
            return count;
        }

    }
}
