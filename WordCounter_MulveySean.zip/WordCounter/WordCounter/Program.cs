﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCounter
{
    /*
     *  Sean Mulvey
     * CSC-253
     * Word Counter
     * 09/10/2020
     */
    public class Program
    {
        public static void Main(string[] args)
        {
            string userString;
            
            // Display prompt to get string
            Console.WriteLine("Enter a string to count the number of words in it: ");
            // get string
            userString = Console.ReadLine();
            // display word count
            Console.WriteLine("There are " + WordCount(userString) + " words in the string.");
            Console.ReadLine();
            

            
        }
        public static int WordCount(string userString)
        {
            int count = 0;
            // create an empty list
            List<string> wordCounter = new List<string>();
            // split each word into a substring and add it to wordCounter list
            wordCounter = userString.Split(' ').ToList();
            // increment count for each word in wordCounter list
            foreach (string value in wordCounter)
            {
                count++;
            }
            return count;
        }

    }
}
