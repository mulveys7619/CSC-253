﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleUI
{
    public class Program
    {
        
        public static void Main(string[] args)
        {
            try
            {
                // Create variable to assign with what is in file
                string distance;
                // Create StreamReader
                StreamReader inputFile;

                
                
                double speed = 0;
                double time = 0;
                // Input speed and time
                Console.WriteLine("Enter speed (mph) and time (hour) to calculate distance traveled: ");
                speed = InputValidation(speed);
                time = InputValidation(time);

                // Call WriteToFile()
                WriteToFile(CalculateDistance(speed, time));
                // Set inputFile to open distance.txt
                inputFile = File.OpenText("distance.txt");
                // Set distance to what was read in the file
                distance = inputFile.ReadLine();
                // Display what was read in the Console
                Console.WriteLine(distance);

                inputFile.Close();

                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            Console.ReadLine();
        }
        public static double CalculateDistance(double speed, double time)
        {
            double distance = speed * time;
            return distance;
        }
        public static double InputValidation(double input)
        {
            while (!double.TryParse(Console.ReadLine(), out input))
            {
                Console.WriteLine("ERROR: Please enter a valid value!");
            }

            return input;

        }
        // Write distance traveled method to distance.txt
        public static void WriteToFile(double distance)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("distance.txt");

                outputFile.WriteLine("The distance traveled is " + distance + " miles.");
                outputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            
        }
    }
}
