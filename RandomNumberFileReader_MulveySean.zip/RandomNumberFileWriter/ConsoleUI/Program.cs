﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace ConsoleUI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Random random = new Random();
                StreamWriter outputFile;
                int userNum = 0;
                
                outputFile = File.CreateText("RandomNumbers.txt");
                Console.WriteLine("How many random numbers do you want to add?: ");
                userNum = IntValidation(userNum);

                for (int i = 0; i < userNum; i++)
                {
                    int randomNumber = random.Next(1, 100);
                    outputFile.WriteLine(randomNumber);
                    
                }
                outputFile.Close();
                ReadFile();
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }


        }
        public static int IntValidation(int num)
        {
            while (!int.TryParse(Console.ReadLine(), out num))
            {
                Console.WriteLine("Error: Please enter a valid value!");
            }

            return num;
        }
        public static void ReadFile()
        {
            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText("RandomNumbers.txt");
                
                int count = 0;
                Console.WriteLine("Numbers in RandomNumbers.txt");
                Console.WriteLine("----------------------------");
                while (!inputFile.EndOfStream)
                {
                    Console.WriteLine(inputFile.ReadLine());
                    count++;
                }
                Console.WriteLine("Total numbers in File: " + count);
                inputFile.Close();
                Console.ReadLine();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

    }
}
